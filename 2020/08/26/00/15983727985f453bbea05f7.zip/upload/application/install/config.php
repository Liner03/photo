<?php
return array(
	'html' => '0',
	'TPL_THEME'=>'',
	'LAYOUT'=>true,
);