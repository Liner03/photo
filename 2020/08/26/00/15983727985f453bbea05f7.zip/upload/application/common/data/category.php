<?php
return array (
  '玄幻奇幻' => 
  array (
    'id' => '玄幻奇幻',
    'name' => '玄幻奇幻',
    'num' => '369248',
    'pinyin' => 'qihuan',
  ),
  '女生言情' => 
  array (
    'id' => '女生言情',
    'name' => '女生言情',
    'num' => '381502',
    'pinyin' => 'yanqing',
  ),
  '武侠仙侠' => 
  array (
    'id' => '武侠仙侠',
    'name' => '武侠仙侠',
    'num' => '92429',
    'pinyin' => 'xianxia',
  ),
  '都市异能' => 
  array (
    'id' => '都市异能',
    'name' => '都市异能',
    'num' => '283701',
    'pinyin' => 'yineng',
  ),
  '豪门幻情' => 
  array (
    'id' => '豪门幻情',
    'name' => '豪门幻情',
    'num' => '146019',
    'pinyin' => 'huanqing',
  ),
  '穿越架空' => 
  array (
    'id' => '穿越架空',
    'name' => '穿越架空',
    'num' => '196544',
    'pinyin' => 'jiakong',
  ),
  '科幻悬疑' => 
  array (
    'id' => '科幻悬疑',
    'name' => '科幻悬疑',
    'num' => '80551',
    'pinyin' => 'xuanyi',
  ),
  '历史军事' => 
  array (
    'id' => '历史军事',
    'name' => '历史军事',
    'num' => '99649',
    'pinyin' => 'junshi',
  ),
  '游戏竞技' => 
  array (
    'id' => '游戏竞技',
    'name' => '游戏竞技',
    'num' => '45436',
    'pinyin' => 'jingji',
  ),
  '耽美同人' => 
  array (
    'id' => '耽美同人',
    'name' => '耽美同人',
    'num' => '49172',
    'pinyin' => 'tongren',
  ),
  '其它小说' => 
  array (
    'id' => '其它小说',
    'name' => '其它小说',
    'num' => '665689',
    'pinyin' => 'qita',
  ),
);