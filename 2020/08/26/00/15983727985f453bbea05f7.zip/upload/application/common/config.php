<?php
return array (
  'tpl_theme' => 'default',
  'tpl_protect' => '',
  'log' => true,
  'adminpath' => 'admin',
  'rewritepower' => 1,
  'urlconfig' => 
  array (
    'index_novel_index' => '/novel-{novelid}.html',
    'index_dir_index' => '/dir-{novelid}.html',
    'index_chapter_index' => '/chapter-{novelid}-{chapterid}.html',
    'index_category_index' => '/category-{key}-{page}.html',
    'index_top_index' => '/top-{page}.html',
  ),
  'url_rules' => 
  array (
    'index.index.index' => '/',
    'index.novel.index' => '/novel-{novelid}.html',
    'index.dir.index' => '/dir-{novelid}.html',
    'index.chapter.index' => '/chapter-{novelid}-{chapterid}.html',
    'index.category.index' => '/category-{key}-{page}.html',
    'index.top.index' => '/top-{page}.html',
  ),
  'url_router' => 
  array (
    '^novel-([a-zA-Z0-9]+).html$' => 'index/novel/index?novelid',
    '^dir-([a-zA-Z0-9]+).html$' => 'index/dir/index?novelid',
    '^chapter-([a-zA-Z0-9]+)-(\d+).html$' => 'index/chapter/index?novelid&chapterid',
    '^category-([a-zA-Z0-9]+)-(\d+).html$' => 'index/category/index?key&page',
    '^top-(\d+).html$' => 'index/top/index?page',
  ),
  'plugin' => 
  array (
    'template_compile_end' => 
    array (
       
    ),
  ),
  'runinfo' => '运行时间：{time}秒，内存使用：{mem}MB，API请求：{net}次。',
  'gzip_encode' => false,
  'sitename' => 'PTCMS小说小偷程序',
  'siteurl' => 'http://www.ptxsxt.com',
  'beian' => '京ICP备111111号',
  'email' => 'admin@admin.com',
  'qq' => '10000',
  'addir' => 'ptcms',
  'lastnum' => '15',
  'pagesize' => '10',
  'timeout' => '30',
  'user_agent' => 'PTSingleNovel (build by PTcms.com)',
  'appid' => 'test',
  'appkey' => 'test',
  'apiserver' => 'http://free.api.ptcms.com/novel/sae/read',
  'httpmethod' => 'curl',
  'seo' => 
  array (
    'index' => 
    array (
      'title' => '{$sitename} - 海量小说免费在线阅读',
      'keywords' => '{$sitename},最新章节阅读,txt电子书下载,umd电子书下载',
      'description' => '{$sitename}为小说爱好者提供大量网络小说在线阅读,网站干净无多广告,每天更新数百本热门小说,欢迎各位热爱小说的读者和作者加入{$sitename}大家庭，一起品味看书的快乐！',
    ),
    'novel' => 
    array (
      'title' => '{$novelname}最新章节 / {$author} / {$sitename}',
      'keywords' => '{$novelname}全文阅读,{$novelname}最新章节,{$novelname}电子书下载',
      'description' => '{$sitename}为小说爱好者提供{$author}大大的{$novelname}最近更新章节阅读，{$novelname}全文在线阅读,{$novelname}最新章节电子书下载(包括{$novelname}的TXT格式下载、{$novelname}的JAR格式下载、{$novelname}的UMD格式下载)',
    ),
    'dir' => 
    array (
      'title' => '{$novelname}最新章节列表 - {$author} - {$sitename}',
      'keywords' => '{$novelname}最新章节列表,{$novelname}全文阅读,{$novelname}TXT电子书下载',
      'description' => '{$sitename}为小说爱好者提供{$author}大大的{$novelname}最近更新章节阅读，{$novelname}全文在线阅读,{$novelname}最新章节电子书下载(包括{$novelname}的TXT格式下载、{$novelname}的JAR格式下载、{$novelname}的UMD格式下载)',
    ),
    'chapter' => 
    array (
      'title' => '{$novelname} >> {$chaptername} - {$sitename}',
      'keywords' => '{$chaptername},{$novelname},{$novelname}最新章节免费阅读',
      'description' => '{$sitename}为小说爱好者提供{$novelname}最近更新章节阅读，{$novelname}全文在线阅读,{$novelname}最新章节电子书下载(包括{$novelname}的TXT格式下载、{$novelname}的JAR格式下载、{$novelname}的UMD格式下载)',
    ),
    'category' => 
    array (
      'title' => '{$categoryname} - 小说列表 - {$sitename}',
      'keywords' => '{$categoryname}小说列表,{$categoryname}小说阅读,{$categoryname}小说下载,{$categoryname}小说推荐',
      'description' => '您现在在{$categoryname}小说列表，这里为大家罗列了{$sitename}网为小说爱好者提供的{$categoryname}小说',
    ),
    'top' => 
    array (
      'title' => '小说排行 - {$sitename}',
      'keywords' => '热门小说列表,热门小说阅读,热门小说下载,热门小说推荐',
      'description' => '您现在在热门小说排行列表，这里为大家罗列了{$sitename}网为小说爱好者提供的热门小说排行列表',
    ),
    'search' => 
    array (
      'title' => '搜索“{$searchkey}”的结果 - {$sitename}',
      'keywords' => '{$sitename}',
      'description' => '{$sitename},{$searchkey}',
    ),
  ),
  'friendlink' => 
  array (
    0 => 
    array (
      'name' => 'PTCMS工作室',
      'url' => 'http://www.ptcms.com',
      'desc' => 'PTCMS工作室官方网站',
    ),
    1 => 
    array (
      'name' => '云轩阁',
      'url' => 'http://www.yunxuange.org',
      'desc' => '',
    ),
    2 => 
    array (
      'name' => '起舞中文',
      'url' => 'http://www.75zw.com',
      'desc' => '',
    ),
  ),
  'map_module' => 
  array (
  ),
  'html' => 0,
  'allow_module' => 'ad,admin,build,common,friendlink,index,install,singlenovel,tool,set,user',
  'novelid_offset' => 0,
  'novelid_tobase' => 36,
  'novelid_allow' => 1,
  'wap_domain' => 'm.ptxsxt.com',
  'wap_theme' => 'wap',
);