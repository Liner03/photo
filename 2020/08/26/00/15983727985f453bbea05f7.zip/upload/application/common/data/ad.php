<?php
return array (
  0 => 
  array (
    'name' => '网站统计',
    'key' => 'tongji',
    'code' => '<script language="javascript" type="text/javascript" src="http://js.users.51.la/17332512.js"></script>',
    'canhide' => '0',
  ),
  1 => 
  array (
    'name' => '示例广告1（签到后可以隐藏）',
    'key' => 'signhide',
    'code' => '示例广告代码，该广告在点击签到后可以隐藏<br/>',
    'canhide' => '1',
  ),
  2 => 
  array (
    'name' => '示例广告2（无法隐藏）',
    'key' => 'signnohide',
    'code' => '示例广告代码，该广告将会一直显示，无论是否进行了签到<br/>',
    'canhide' => '0',
  ),
  3 => 
  array (
    'name' => '全站弹窗广告',
    'key' => 'window',
    'code' => '全站弹窗广告 修改或删除该广告位请到后台进行操作',
    'canhide' => '0',
  ),
  4 => 
  array (
    'name' => '全站悬浮广告',
    'key' => 'float',
    'code' => '全站悬浮广告 修改或删除该广告位请到后台进行操作',
    'canhide' => '0',
  ),
  5 => 
  array (
    'name' => '导航下广告位',
    'key' => 'navbottom',
    'code' => '<div class="adbox" style="width:1200px;height:90px;line-height:90px;">
广告位 1200*90
</div>',
    'canhide' => '0',
  ),
  6 => 
  array (
    'name' => '书页中栏广告',
    'key' => 'infomiddle',
    'code' => '<div class="adbox" style="width:855px;height:70px;line-height:70px;float:left;margin-top:15px">
广告位 855*70
</div>',
    'canhide' => '0',
  ),
  7 => 
  array (
    'name' => '边栏广告位',
    'key' => 'sidebar',
    'code' => '<div class="adbox" style="width:320px;height:200px;line-height:200px;padding:0 4px;margin-bottom:10px;">
广告位 320*200
</div>',
    'canhide' => '0',
  ),
  8 => 
  array (
    'name' => '目录页中部广告位',
    'key' => 'dirmiddle',
    'code' => '<div style="width:855px;height:70px;line-height:70px;text-align:center">
广告位 855*70
</div>',
    'canhide' => '0',
  ),
  9 => 
  array (
    'name' => '章节内容上',
    'key' => 'chaptercontenttop',
    'code' => '<div class="adbox" style="width:855px;height:70px;line-height:70px;float:left;margin-top:15px">
广告位 855*70
</div>',
    'canhide' => '0',
  ),
  10 => 
  array (
    'name' => '章节内容下',
    'key' => 'chaptercontentbottom',
    'code' => '<div class="adbox" style="width:855px;height:70px;line-height:70px;float:left;margin-top:15px">
广告位 855*70
</div>',
    'canhide' => '0',
  ),
);