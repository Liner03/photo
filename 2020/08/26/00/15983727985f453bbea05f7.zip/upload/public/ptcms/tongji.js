document.writeln("<script language=\"javascript\" type=\"text/javascript\" src=\"http://js.users.51.la/17332512.js\"></script>");
