document.writeln("<div class=\"adbox\" style=\"width:1200px;height:90px;line-height:90px;\">");
document.writeln("广告位 1200*90");
document.writeln("</div>");
