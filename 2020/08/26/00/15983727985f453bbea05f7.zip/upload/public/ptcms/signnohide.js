document.writeln("示例广告代码，该广告将会一直显示，无论是否进行了签到<br/>");
