document.writeln("<div class=\"adbox\" style=\"width:855px;height:70px;line-height:70px;float:left;margin-top:15px\">");
document.writeln("广告位 855*70");
document.writeln("</div>");
