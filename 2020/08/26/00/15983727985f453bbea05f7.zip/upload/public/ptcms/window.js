document.writeln("全站弹窗广告 修改或删除该广告位请到后台进行操作");
