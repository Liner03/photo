document.writeln("<div style=\"width:855px;height:70px;line-height:70px;text-align:center\">");
document.writeln("广告位 855*70");
document.writeln("</div>");
