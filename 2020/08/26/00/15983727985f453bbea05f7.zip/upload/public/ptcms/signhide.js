if ($.cookie("PTCMS_sign")==undefined){document.writeln("示例广告代码，该广告在点击签到后可以隐藏<br/>");
}