document.writeln("<div class=\"adbox\" style=\"width:320px;height:200px;line-height:200px;padding:0 4px;margin-bottom:10px;\">");
document.writeln("广告位 320*200");
document.writeln("</div>");
