<?php
return array (
  'jdt' => 
  array (
    'name' => '焦点图',
    'value' => '魔天记|完美世界|莽荒纪|绝世唐门',
  ),
  'bjtjtop' => 
  array (
    'name' => '编辑推荐头条',
    'value' => '天醒之路',
  ),
  'bjtj' => 
  array (
    'name' => '编辑推荐列表',
    'value' => '大主宰|我欲封天|绝世武神|择天记|武极天下|灵域|永夜君王|校花的贴身高手|星战风暴',
  ),
  'viptop' => 
  array (
    'name' => 'vip推荐头条',
    'value' => '英雄联盟之谁与争锋|星河大帝',
  ),
  'vip' => 
  array (
    'name' => 'vip推荐列表',
    'value' => '剑道独尊|傲世九重天|最强弃少|天骄无双',
  ),
);