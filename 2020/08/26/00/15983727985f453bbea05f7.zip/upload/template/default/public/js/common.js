var sco = function () {
var a = $(document).scrollTop();
if (a > 0) {
$(".top_bg").css("border-bottom", "1px solid #cccccc");
$(".logo").css("height", 55);
$(".logo_left img").css("height", 55);
$(".logo_left img").css("margin-top", "0");
$(".logo_middle").css("height", 55);
$(".logo_middle").css("backgroundPosition", "0 5px");
$(".search_txt").css("top", 11);
$(".search_btn").css("top", 5);
$(".logo_middle a").css("top", 5);
$(".logo_right").css("padding-top", "0");
} else {
$(".top_bg").css("border-bottom", "0");
$(".logo").css("height", 122);
$(".logo_left img").css("height", 82);
$(".logo_left img").css("margin-top", "15px");
$(".logo_middle").css("height", 122);
$(".logo_middle").css("backgroundPosition", "0 35px");
$(".search_txt").css("top", 41);
$(".search_btn").css("top", 35);
$(".logo_middle a").css("top", 35);
$(".logo_right").css("padding-top", 30);
}
if ($("#float").length > 0) {
var lheight = $("#floatleft").height();
var rheight = $("#float").height();
var sheight = lheight - rheight - 20;
var startf = $("#floatleft").offset().top - 100 + 15;
if (a > startf) {
if (a > startf + sheight) {
$("#float").removeClass("float");
document.getElementById("float").style.marginTop = sheight + "px";
} else {
$("#float").addClass("float");
$("#float").css("margin-top", "10px");
}
} else {
$("#float").removeClass("float");
$("#float").css("margin-top", "0px");
}
}
};
$(function () {
$(document).on('scroll', function () {
sco();
});
sco();
});

