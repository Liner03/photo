<?php
/***************************************************************
 *   Program: PTCMS小说小偷程序VIP - PTNovelStealVIP
 *   Version: 3.0.3
 *   WebSite: http://www.ptcms.com
 *   License: http://www.ptcms.com/help/license
 * Copyright: 2009 - 2014 Ptcms Studio
 *      Date: 2014-10-28 16:18:59
 *      File: index.php
 **************************************************************/


define('PRONAME', 'PTCMS小说小偷程序VIP');
define('PROENNAME', 'PTNovelStealVIP');
define('PROVERSION', '3.0.3');
define('PROTIME', '20141027');

include dirname(__FILE__).'/ptcms/ptcms.php';